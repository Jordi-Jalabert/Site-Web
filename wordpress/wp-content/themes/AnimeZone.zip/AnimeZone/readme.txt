Anime Zone theme by FlexiThemes, https://flexithemes.com
Online Demo: https://flexithemes.com/demo/AnimeZone/
Theme URI: https://flexithemes.com/anime-zone-wordpress-theme/